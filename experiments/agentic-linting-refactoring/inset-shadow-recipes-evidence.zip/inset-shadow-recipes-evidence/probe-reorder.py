import json,time,concurrent.futures
from drive import c,R,key
rows=json.loads((R/f'{key}-automations.json').read_text());alpha,beta=[r['id']for r in rows]
c('browser','viewport','desktop');c('browser','goto','/settings/app');c('browser','click','testid=color-theme-input');c('browser','click','role=option[name="OpenHands-Neutral"]');c('browser','goto','/');c('browser','scroll','testid=pinned-automations-dashboard');c('browser','record','start','--feature','reorder-shadow-diagnostic','--name',key+'-held-target')
expr="""(async()=>{const states=new Map(),start=performance.now();while(performance.now()-start<5000){for(const e of document.querySelectorAll('[data-testid^=pinned-automation-card-]')){const v={name:e.innerText.split('\\n')[0],className:e.className,shadow:getComputedStyle(e).boxShadow,opacity:getComputedStyle(e).opacity};const k=JSON.stringify(v);if(!states.has(k))states.set(k,{...v,ms:Math.round(performance.now()-start)})}await new Promise(r=>setTimeout(r,8))}return [...states.values()]})()"""
with concurrent.futures.ThreadPoolExecutor(max_workers=1)as pool:
 result=pool.submit(c,'browser','eval',expr);time.sleep(.2)
 for position in ['before','after']:c('browser','drag','testid=pinned-automation-drag-'+beta,'testid=pinned-automation-card-'+alpha,'--position',position,'--steps','60');time.sleep(.15)
 observed=result.result()
video=c('browser','record','stop');shot=c('browser','screenshot','--feature','reorder-shadow-diagnostic','--name',key+'-after-held-drag');flags=[v for v in observed['value']if 'shadow-['in v['className']or'shadow-reorder-'in v['className']]
report={'source':'original main baseline 29126107d771233d290973dfc22ae6a0527d2751'if key=='reorder_before'else'df96b8e0c00887d94f815e5a18430fc9267027ea','setup':'real Local standalone Canvas, unmodified control-openhands, installed Chrome, SDK 1.60.1; keyless diagnostic, no model execution','observed':observed,'targetClassObservations':flags,'video':video,'screenshot':shot,'verdict':'REPRODUCED'if flags and all(v['shadow']=='none'for v in flags)else'INCONCLUSIVE'};(R/f'{key}-shadow-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
for r in rows:
 runs=c('api','GET','/api/automation/v1/'+r['id']+'/runs');assert runs['body']['total']==0;c('api','PATCH','/api/automation/v1/'+r['id'],'--write','--data',json.dumps({'enabled':False}))
print(report['verdict'],len(flags),'actual target-class states observed; no automation runs; fixtures disabled',flush=True)
