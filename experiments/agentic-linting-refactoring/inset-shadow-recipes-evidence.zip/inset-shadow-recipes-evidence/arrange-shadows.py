import json
from drive import c,R,key
rows=json.loads((R/f'{key}-automations.json').read_text())
for r in rows:
 c('api','PATCH','/api/automation/v1/'+r['id'],'--write','--data',json.dumps({'enabled':True}))
c('browser','viewport','desktop');c('browser','goto','/')
for r in rows:
 c('browser','wait','testid=running-automation-row-'+r['id']);c('browser','click','testid=running-automation-menu-'+r['id']);c('browser','click','testid=running-automation-pin-'+r['id'])
c('browser','wait','testid=pinned-automations-dashboard');receipts=[]
for r in rows:receipts.append({'id':r['id'],'runs':c('api','GET','/api/automation/v1/'+r['id']+'/runs')})
(R/f'{key}-never-dispatched-before.json').write_text(json.dumps(receipts,indent=2)+'\n');print(key,'real unregistered-event fixtures pinned; no dispatch',flush=True)
