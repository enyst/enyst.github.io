import json
from drive import c,R,key
fixtures=[]
for name in ['QA metrics Alpha','QA metrics Beta']:
 r=c('api','POST','/api/automation/v1/preset/prompt','--write','--data',json.dumps({'name':name,'prompt':'Owned inert UI fixture, never dispatch. Do not run any tools.','trigger':{'type':'event','source':'qa-metrics-reorder-diagnostic','on':'qa.metrics.diagnostic.never'}}));fixtures.append({'name':name,'id':r['body']['id']})
(R/f'{key}-automations.json').write_text(json.dumps(fixtures,indent=2)+'\n')
c('browser','goto','/')
for r in fixtures:
 c('browser','wait','testid=running-automation-row-'+r['id']);c('browser','click','testid=running-automation-menu-'+r['id']);c('browser','click','testid=running-automation-pin-'+r['id'])
c('browser','wait','testid=pinned-automations-dashboard');print('Keyless diagnostic baseline ready; no model or automation execution',flush=True)
