import json,time,concurrent.futures
from drive import c,R,key
out=[]
def observe(selector):
 return c('browser','eval',"(()=>{const e=document.querySelector("+json.dumps(selector)+");if(!e)throw Error('Missing live badge');const s=getComputedStyle(e),r=e.getBoundingClientRect();return {shadow:s.boxShadow,border:s.borderColor,background:s.backgroundColor,width:r.width,height:r.height,contrast:s.getPropertyValue('--oh-contrast').trim(),focus:s.getPropertyValue('--oh-focus').trim()}})()")
for theme,label in [('openhands-neutral','OpenHands-Neutral'),('openhands-deepsea','OpenHands-DeepSea'),('openhands-neo','OpenHands-Neo'),('light-plus','Light+'),('solarized-light','Solarized Light'),('paper','Paper')]:
 c('browser','viewport','desktop');c('browser','goto','/settings/app');c('browser','click','testid=color-theme-input');c('browser','click',f'role=option[name="{label}"]')
 for view in ['desktop','phone']:
  c('browser','viewport',view);c('browser','goto','/skills');c('browser','fill','role=searchbox[name="Search skills by name, description, or trigger"]','qa-metrics-badge');c('browser','wait','testid=skill-icon-qa-metrics-badge');c('browser','record','start','--feature','inset-shadow-recipes','--name',f'{key}-{theme}-{view}-badges');frames=[]
  def shot(state,selector):frames.append({'state':state,'computed':observe(selector),'screenshot':c('browser','screenshot','--feature','inset-shadow-recipes','--name',f'{key}-{theme}-{view}-{state}')})
  shot('skill','[data-testid=skill-icon-qa-metrics-badge]')
  c('browser','goto','/mcp');c('browser','wait','testid=mcp-marketplace-card-github');c('browser','scroll','testid=mcp-marketplace-card-github');shot('mcp','[data-testid=mcp-marketplace-card-github] span[title="GitHub"]')
  c('browser','goto','/automations/templates');sel='testid=recommended-automation-icon-linear-issue-to-github-pr';c('browser','wait',sel);c('browser','scroll',sel);shot('stack','[data-testid=recommended-automation-icon-linear-issue-to-github-pr]')
  out.append({'theme':theme,'viewport':view,'frames':frames,'video':c('browser','record','stop')});(R/f'{key}-shadows-captures.json').write_text(json.dumps(out,indent=2)+'\n')
 print(key,theme,'badge desktop/phone captured',flush=True)

rows=json.loads((R/f'{key}-automations.json').read_text());alpha,beta=[r['id']for r in rows];drags=[]
order="(()=>[...document.querySelectorAll('[data-testid^=pinned-automation-card-]')].map(e=>e.innerText.split('\\n')[0]))()"
# This promise only reads actual computed styles during native pointer moves.
observeDrag="""(async()=>{const states=new Map(),start=performance.now();while(performance.now()-start<7000){for(const e of document.querySelectorAll('[data-testid^=pinned-automation-card-]')){const s=getComputedStyle(e),v={name:e.innerText.split('\\n')[0],shadow:s.boxShadow,opacity:s.opacity};const key=JSON.stringify(v);if(!states.has(key))states.set(key,{...v,ms:Math.round(performance.now()-start)})}await new Promise(r=>setTimeout(r,16))}return [...states.values()]})()"""
for theme,label in [('openhands-neutral','OpenHands-Neutral'),('paper','Paper')]:
 c('browser','viewport','desktop');c('browser','goto','/settings/app');c('browser','click','testid=color-theme-input');c('browser','click',f'role=option[name="{label}"]')
 for view in ['desktop','phone']:
  c('browser','viewport',view);c('browser','goto','/');c('browser','wait','testid=pinned-automations-dashboard');c('browser','scroll','testid=pinned-automations-dashboard');before=c('browser','eval',order);c('browser','record','start','--feature','inset-shadow-recipes','--name',f'{key}-{theme}-{view}-reorder')
  with concurrent.futures.ThreadPoolExecutor(max_workers=1)as pool:
   observations=pool.submit(c,'browser','eval',observeDrag);time.sleep(.2);steps=[]
   for position in ['before','after']:
    source='testid=pinned-automation-drag-'+beta;target='testid=pinned-automation-card-'+alpha
    a=c('browser','bbox',source)['box'];b=c('browser','bbox',target)['box'];horizontal=abs(a['x']-b['x'])>b['width']*.5
    tx=b['x']+b['width']*(.15 if position=='before'else .85)if horizontal else b['x']+b['width']*.5
    ty=b['y']+b['height']*(.5 if horizontal else (.15 if position=='before'else .85));dx=tx-(a['x']+a['width']/2);dy=ty-(a['y']+a['height']/2)
    c('browser','drag',source,'--by',f'{dx},{dy}','--steps','100');steps.append({'position':position,'order':c('browser','eval',order)});time.sleep(.25)
   values=observations.result()
  after=c('browser','eval',order);shot=c('browser','screenshot','--feature','inset-shadow-recipes','--name',f'{key}-{theme}-{view}-reorder-restored');clip=c('browser','record','stop');c('browser','reload');restored=c('browser','eval',order)
  assert before['value']==after['value']==restored['value'],(before,steps,after,restored)
  assert steps[0]['order']['value']!=before['value'],(before,steps)
  drags.append({'theme':theme,'viewport':view,'before':before,'steps':steps,'after':after,'persisted':restored,'computed':values,'screenshot':shot,'video':clip});(R/f'{key}-reorder-captures.json').write_text(json.dumps(drags,indent=2)+'\n');print(key,theme,view,'native reorder/restoration captured',flush=True)
receipts=[]
for r in rows:
 a=c('api','GET','/api/automation/v1/'+r['id']+'/runs');assert a['body']['total']==0,a;d=c('api','PATCH','/api/automation/v1/'+r['id'],'--write','--data',json.dumps({'enabled':False}));assert d['body']['enabled']is False;receipts.append({'id':r['id'],'runs':a,'disabledAfterCapture':True})
(R/f'{key}-never-dispatched-after.json').write_text(json.dumps(receipts,indent=2)+'\n')
