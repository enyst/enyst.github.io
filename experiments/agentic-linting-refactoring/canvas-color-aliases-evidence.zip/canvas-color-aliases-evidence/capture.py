import json,time
from drive import c,R,key
obs="""(()=>{const ids=['add-models-provider','add-models-connection','add-models-submit','agent-profile-active-badge'];const out={};for(const id of ids){const e=document.querySelector('[data-testid="'+id+'"]');if(!e)continue;const s=getComputedStyle(e),r=e.getBoundingClientRect();out[id]={color:s.color,backgroundColor:s.backgroundColor,fontSize:s.fontSize,lineHeight:s.lineHeight,opacity:s.opacity,disabled:e.disabled??null,width:r.width,height:r.height,x:r.x,y:r.y,publicBackground:s.getPropertyValue('--oh-background').trim(),publicOnAccent:s.getPropertyValue('--oh-accent-foreground').trim()}}return out})()"""
out=[]
for theme,label in [('openhands-neutral','OpenHands-Neutral'),('openhands-deepsea','OpenHands-DeepSea'),('openhands-neo','OpenHands-Neo'),('light-plus','Light+'),('solarized-light','Solarized Light'),('paper','Paper')]:
 c('browser','viewport','desktop');c('browser','goto','/settings/app');c('browser','click','testid=color-theme-input');c('browser','click',f'role=option[name="{label}"]')
 for view in ['desktop','phone']:
  c('browser','viewport',view);c('browser','goto','/settings/llm');c('browser','click','testid=add-models-from-provider');c('browser','select','testid=add-models-provider','deepseek');c('browser','wait','testid=add-models-select-all')
  c('browser','record','start','--feature','canvas-color-aliases','--name',f'{key}-{theme}-{view}')
  frames=[]
  for state,enabled in [('disabled',False),('enabled',True)]:
   if enabled:c('browser','check','testid=add-models-select-all')
   value=c('browser','enabled','testid=add-models-submit');computed=c('browser','eval',obs);shot=c('browser','screenshot','--feature','canvas-color-aliases','--name',f'{key}-{theme}-{view}-{state}')
   frames.append({'state':state,'enabled':value,'computed':computed,'screenshot':shot})
  c('browser','click','role=dialog[name="Add models as profiles"] >> role=button[name="Cancel"]');c('browser','goto','/settings/agents');c('browser','wait','testid=agent-profile-active-badge')
  frames.append({'state':'badge','computed':c('browser','eval',obs),'screenshot':c('browser','screenshot','--feature','canvas-color-aliases','--name',f'{key}-{theme}-{view}-badge')})
  out.append({'theme':theme,'viewport':view,'frames':frames,'video':c('browser','record','stop')});(R/f'{key}-captures.json').write_text(json.dumps(out,indent=2))
 print(key,theme,'desktop/phone captured',flush=True)
