from pathlib import Path
import subprocess,json,re,os,hashlib
R=Path('/tmp/agentic-lint-catalog-nov08');W=Path('/tmp/agentic-lint-catalog-proof-nov08');D=R/'controls';D.mkdir(exist_ok=True);test=W/'__tests__/themes/color-themes.test.tsx';product=W/'src/components/features/skills/build-skill-pills.tsx';originalTest=test.read_text();originalProduct=product.read_text();env=os.environ.copy();env['PATH']='/tmp/agentic-lint-wave3-nov07/bin:'+env['PATH']
needle='          const ink = paint(sample.ink);';assert needle in originalTest;instrumented=originalTest.replace(needle,needle+'\n          console.log("CATALOG_EXERCISE", JSON.stringify({theme: _key, surfaceRole, sample: sample.name, ink: ink.color, inkAlpha: ink.alpha, backgroundAlpha: background.alpha, background: background.color, card, ratio: contrast(luminance(ink.color), luminance(surface)), minimum: sample.minimum}));',1)
subprocess.run(['npm','run','make-i18n'],cwd=W,env=env,check=True,stdout=(D/'i18n.log').open('w'),stderr=subprocess.STDOUT)
def run(name,testSource,productSource,expected):
 test.write_text(testSource);product.write_text(productSource);p=subprocess.run(['node',str(W/'node_modules/vitest/vitest.mjs'),'run','__tests__/themes/color-themes.test.tsx','--silent=false'],cwd=W,env=env,capture_output=True,text=True);text=re.sub(r'\x1b\[[0-9;]*m','',p.stdout+p.stderr);(D/(name+'.log')).write_text(text);assert(p.returncode==0)==expected,(name,p.returncode,text[-1500:]);rows=[json.loads(x)for x in re.findall(r'CATALOG_EXERCISE (\{[^\n]+\})',text)];(D/(name+'-samples.json')).write_text(json.dumps(rows,indent=2)+'\n');summary={'name':name,'exitCode':p.returncode,'samples':len(rows),'testTotals':[x.strip()for x in text.splitlines()if re.search(r'^\s*(?:Tests|Test Files)\s',x)],'violations':[r for r in rows if r['ratio']<r['minimum']]};print(name,'exit',p.returncode,'observed',len(rows),'violations',len(summary['violations']),flush=True);return summary
try:
 plain=run('unmodified',originalTest,originalProduct,True)
 observed=run('observed-current',instrumented,originalProduct,True);assert observed['samples']==72 and not observed['violations']
 dot='''        name: "manual-only dot",
        ink: paint(badge.firstElementChild!, "background-color"),
        background: paint(badge, "background-color"),''';assert dot in instrumented
 opaque=run('opaque-dot-negative-control',instrumented.replace(dot,dot.replace('background: paint(badge, "background-color")','background: paint(badge.firstElementChild!, "background-color")')),originalProduct,False);assert len(opaque['violations'])==6 and all(abs(x['ratio']-1)<1e-10 for x in opaque['violations'])
 pink=run('fixed-pink-product-regression',instrumented,originalProduct.replace('text-feedback-error','text-[#fca5a5]'),False);assert any(x['sample']=='manual-only text'for x in pink['violations'])
 restored=run('restored-current',originalTest,originalProduct,True)
finally:test.write_text(originalTest);product.write_text(originalProduct)
assert not subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).strip()
subprocess.run(['git','diff','--exit-code'],cwd=W,check=True,stdout=subprocess.DEVNULL)
(D/'instrumentation.diff').write_text(subprocess.check_output(['git','diff','--no-index','--','/dev/null','/dev/null'],cwd=W,text=True))
# Preserve the exact added observation statement and mutation definitions; no PR code changes.
(D/'control-definitions.json').write_text(json.dumps({'instrumentation':instrumented.split(needle,1)[1].split('          expect(',1)[0],'opaqueDotMutation':'Use dot ink as background only in the isolated test sample; yields alpha 1 and contrast 1.','pinkMutation':'Restore the original fixed text-[#fca5a5] product class in the isolated checkout.'},indent=2)+'\n')
record={'verdict':'PASS','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'prBranchUnchanged':True,'proofWorktreeRestoredClean':True,'originalTestSha256':hashlib.sha256(originalTest.encode()).hexdigest(),'originalProductSha256':hashlib.sha256(originalProduct.encode()).hexdigest(),'runs':[plain,observed,opaque,pink,restored],'observedMinima':{name:min(r['ratio']for r in json.loads((D/'observed-current-samples.json').read_text())if r['sample']==name)for name in ['remove','remove hover','manual-only text','manual-only dot']}}
(D/'report.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record['observedMinima']),flush=True)
