import fs from 'node:fs';import {ESLint} from './audit/node_modules/eslint/lib/api.js';
const R='/tmp/agentic-lint-next-nov08',key=process.argv[2],repo=R+'/'+(key==='before'?'audit':'guards'),e=new ESLint({cwd:repo});
const paths=[...JSON.parse(fs.readFileSync(R+'/guard-owners.json')),'src/routes/color-probe.tsx','src/ui/color-probe.tsx','src/components/features/backends/backend-status-dot.tsx'];const rows=[];
for(const path of paths){const source=path.endsWith('.ts')?'import {cn} from "#/utils/utils"; export const probe=cn("w-[123px]");':'export function Probe(){ return <div className="w-[123px] text-red-500 text-[#ec4899]"/>; }';const [r]=await e.lintText(source,{filePath:path});const cfg=await e.calculateConfigForFile(path);rows.push({path,rules:cfg.rules,messages:r.messages.map(({ruleId,severity,message})=>({ruleId,severity,message}))})}
fs.writeFileSync(R+'/guards-'+key+'-diagnostics.json',JSON.stringify(rows,null,2)+'\n');console.log(key,rows.length,'real config probes');
