(() => {
  const card = document.querySelector('[data-testid=skill-card-qa-manual-only]');
  const badge = card.querySelector('[data-testid=skill-disable-model-invocation-qa-manual-only]');
  const button = card.querySelector('[data-testid=skill-toggle-qa-manual-only]');
  const dot = badge.firstElementChild;
  const glyph = button.querySelector('svg path');
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 1;
  const ctx = canvas.getContext('2d', {colorSpace: 'srgb', willReadFrequently: true});
  function pixel(paints) {
    ctx.clearRect(0, 0, 1, 1);
    for (const paint of paints) {
      ctx.fillStyle = paint;
      ctx.fillRect(0, 0, 1, 1);
    }
    return Array.from(ctx.getImageData(0, 0, 1, 1).data).slice(0, 3);
  }
  function luminance(rgb) {
    const linear = rgb.map(value => {
      const c = value / 255;
      return c <= .04045 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4;
    });
    return linear[0] * .2126 + linear[1] * .7152 + linear[2] * .0722;
  }
  function contrast(ink, surface) {
    const pair = [luminance(ink), luminance(surface)].sort((a, b) => b - a);
    return (pair[0] + .05) / (pair[1] + .05);
  }
  function sample(element, ink) {
    const paints = [];
    for (let node = element; node; node = node.parentElement) {
      paints.unshift(getComputedStyle(node).backgroundColor);
    }
    const inkRgb = pixel([ink]);
    const backgroundRgb = pixel(paints);
    return {ink, tint: getComputedStyle(element).backgroundColor, inkRgb, backgroundRgb,
      ratio: contrast(inkRgb, backgroundRgb)};
  }
  return {theme:localStorage.getItem('openhands-color-theme'),
    actualCard: getComputedStyle(card).backgroundColor,
    baseSecondary: getComputedStyle(card).getPropertyValue('--oh-color-base-secondary').trim(),
    feedbackError: getComputedStyle(card).getPropertyValue('--oh-feedback-error').trim(),
    remove: button.dataset.showingRemove, hover:button.matches(':hover'),
    badge:sample(badge,getComputedStyle(badge).color),
    dot:sample(badge,getComputedStyle(dot).backgroundColor),
    removeIcon:sample(button,getComputedStyle(glyph).stroke)};
})()
