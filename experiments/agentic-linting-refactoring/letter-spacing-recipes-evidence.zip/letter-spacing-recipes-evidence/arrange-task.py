import json,subprocess,time
from drive import c,R,key,cli,run,env
prompt="Use only your task_tracker tool to record exactly two tasks: 'QA first item' completed and 'QA second item' pending. Do not run terminal, file, web, or other tools. Do not inspect any files. Then reply only DONE."
r=c('conversation','start','--workspace','qa-metrics','--prompt',prompt);(R/f'{key}-task-conversation.json').write_text(json.dumps(r,indent=2)+'\n')
with (R/f'{key}-task-wait.json').open('w')as out,(R/f'{key}-task-wait.log').open('w')as err:
 p=subprocess.Popen([str(cli),'conversation','wait',r['id'],'--timeout','240','--run',str(run)],stdout=out,stderr=err,env=env)
 while p.poll()is None:
  e=c('conversation','events',r['id'],'--kinds','ActionEvent')
  if any(v.get('tool')!='task_tracker'for v in e['events']):
   c('conversation','pause',r['id']);p.terminate();raise RuntimeError('Unexpected tool; owned conversation paused')
  time.sleep(1)
 assert p.returncode==0,'Task conversation did not finish successfully'
e=c('conversation','events',r['id'],'--kinds','ActionEvent');(R/f'{key}-task-events.json').write_text(json.dumps(e,indent=2)+'\n');assert e['count']>0 and all(v.get('tool')=='task_tracker'for v in e['events']),e;print(key,'real task-tracker conversation completed; no other tools',flush=True)
