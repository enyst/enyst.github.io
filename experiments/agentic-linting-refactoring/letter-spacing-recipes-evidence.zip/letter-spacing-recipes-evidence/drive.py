from pathlib import Path
import subprocess,sys,json,os
R=Path('/tmp/agentic-lint-metrics-nov08'); key=sys.argv[1];repo=R/({'before':'audit','reorder_before':'audit'}.get(key,key));run=Path('/var/folders/15/pyrd6jhs3tnd259qd39xsplm0000gn/T/openhands-verify')/({'before':'metrics-main-before-nov08','reorder_before':'metrics-reorder-before-extra-nov08'}.get(key,'metrics-'+key+'-after-nov08'));cli=repo/'.agents/skills/verify-openhands/scripts/control-openhands';env=os.environ.copy();env['PATH']='/tmp/agentic-lint-wave3-nov07/bin:'+env['PATH']
def c(*args):
 p=subprocess.run([str(cli),*args,'--run',str(run)],capture_output=True,text=True,env=env)
 with(R/(key+'-actions.jsonl')).open('a') as f:f.write(json.dumps({'args':args,'code':p.returncode,'out':p.stdout,'err':p.stderr})+'\n')
 if p.returncode:raise RuntimeError(str(args)+p.stdout[-1500:]+p.stderr[-500:])
 return json.loads(p.stdout)
if __name__=='__main__':print(json.dumps(c(*sys.argv[2:])))
