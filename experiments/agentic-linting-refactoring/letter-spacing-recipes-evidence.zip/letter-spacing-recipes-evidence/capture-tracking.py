import json,time
from drive import c,R,key
conv=json.loads((R/f'{key}-conversation.json').read_text())['id'];task=json.loads((R/f'{key}-task-conversation.json').read_text())['id'];out=[]
def observe(selector):
 return c('browser','eval',"(()=>{const e="+selector+";if(!e)throw Error('Missing live typography target');const s=getComputedStyle(e),r=e.getBoundingClientRect();return {tag:e.tagName,text:e.textContent.trim(),letterSpacing:s.letterSpacing,fontSize:s.fontSize,fontWeight:s.fontWeight,lineHeight:s.lineHeight,color:s.color,width:r.width,height:r.height}})()")
for theme,label in [('openhands-neutral','OpenHands-Neutral'),('paper','Paper')]:
 c('browser','viewport','desktop');c('browser','goto','/settings/app');c('browser','click','testid=color-theme-input');c('browser','click',f'role=option[name="{label}"]')
 for view in ['desktop','phone']:
  c('browser','viewport',view);c('browser','goto','/settings/secrets');c('browser','record','start','--feature','letter-spacing-recipes','--name',f'{key}-{theme}-{view}');frames=[]
  def shot(state,selector):
   frames.append({'state':state,'computed':observe(selector),'screenshot':c('browser','screenshot','--feature','letter-spacing-recipes','--name',f'{key}-{theme}-{view}-{state}')})
  shot('heading',"document.querySelector('[data-testid=settings-screen] h2')")
  c('browser','goto','/settings/llm');c('browser','click','testid=add-models-from-provider');shot('modal-title',"document.getElementById('modal-title')");c('browser','press','Escape')
  c('browser','goto','/conversations/'+conv);c('browser','wait','testid=agent-message >> h2');c('browser','scroll','testid=agent-message >> h2');shot('markdown-heading',"document.querySelector('[data-testid=agent-message] h2')")
  c('browser','click','testid=chat-plus-button');c('browser','click','testid=show-skills-button');c('browser','wait','testid=skills-modal >> section');shot('section-label',"document.querySelector('[data-testid=skills-modal] section > div span')");c('browser','press','Escape')
  c('browser','goto','/conversations/'+task);c('browser','wait-text','QA second item');c('browser','scroll','text="QA first item"');shot('metadata',"[...document.querySelectorAll('[data-testid=chat-scroll-container] span')].find(e=>e.textContent==='Tasks')")
  out.append({'theme':theme,'viewport':view,'frames':frames,'video':c('browser','record','stop')});(R/f'{key}-tracking-captures.json').write_text(json.dumps(out,indent=2)+'\n')
 print(key,theme,'typography desktop/phone captured',flush=True)
